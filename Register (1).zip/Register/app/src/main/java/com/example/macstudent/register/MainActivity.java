package com.example.macstudent.register;

import android.content.DialogInterface;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    EditText Username;
    EditText Password;
    EditText FirstName;
    EditText LastName;
    EditText Email;
    Switch RegLog;
    Button Register;
    Button Login;
    TextView textView;

    ArrayList<String> username = new ArrayList<>();
    ArrayList<String> password = new ArrayList<>();
    ArrayList<String> firstname = new ArrayList<>();
    ArrayList<String> lastname = new ArrayList<>();
    ArrayList<String> email = new ArrayList<>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Username = findViewById(R.id.Username);
        Password = findViewById(R.id.Password);
        FirstName = findViewById(R.id.FirstName);
        LastName = findViewById(R.id.LastName);
        Email = findViewById(R.id.Email);
        Register = findViewById(R.id.Register);
        Login = findViewById(R.id.Login);
        textView = findViewById(R.id.withText);

        RegLog = (Switch) findViewById(R.id.RegLog);

        RegLog.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton button, boolean isChecked) {
                if (isChecked) {
                    FirstName.setVisibility(View.INVISIBLE);
                    LastName.setVisibility(View.INVISIBLE);
                    Email.setVisibility(View.INVISIBLE);
                    Register.setVisibility(View.INVISIBLE);
                    Login.setVisibility(View.VISIBLE);
                    textView.setVisibility(View.INVISIBLE);

                } else {
                    FirstName.setVisibility(View.VISIBLE);
                    LastName.setVisibility(View.VISIBLE);
                    Email.setVisibility(View.VISIBLE);
                    Login.setVisibility(View.INVISIBLE);
                    Register.setVisibility(View.VISIBLE);
                    textView.setVisibility(View.INVISIBLE);

                }

            }
        });
    }



    public void RegClick(View view) {

        if (Username.getText().toString().isEmpty())
            Toast.makeText(this, "please provide Username", Toast.LENGTH_SHORT).show();
        else if (Password.getText().toString().isEmpty())
            Toast.makeText(this, " Please provide password", Toast.LENGTH_SHORT).show();
        else if (FirstName.getText().toString().isEmpty())
            Toast.makeText(this, " Please provide yur FirstName", Toast.LENGTH_SHORT).show();
        else if (LastName.getText().toString().isEmpty())
            Toast.makeText(this, " Please provide your lastName", Toast.LENGTH_SHORT).show();
        else if (Email.getText().toString().isEmpty())
            Toast.makeText(this, " Please provide email", Toast.LENGTH_SHORT).show();
        else {

            for (int i = 0; i<username.size(); i++) {
                if (Username.getText().toString().equals(username.get(i).toString())) {
                    Toast.makeText(this, " user already exists", Toast.LENGTH_SHORT).show();
                }
            }
            AlertDialog.Builder pop = new AlertDialog.Builder(this);
            pop.setMessage("Are You Sure");
            pop.setCancelable(true);

            pop.setPositiveButton("Yes, I am sure!", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    username.add(Username.getText().toString());
                    password.add(Password.getText().toString());
                    firstname.add(FirstName.getText().toString());
                    lastname.add(LastName.getText().toString());
                    email.add(Email.getText().toString());

                    Toast.makeText(MainActivity.this, "User registered successfully", Toast.LENGTH_SHORT).show();

                    Username.getText().clear();
                    Password.getText().clear();
                    FirstName.getText().clear();
                    LastName.getText().clear();
                    Email.getText().clear();

                    dialogInterface.cancel();
                }
            });

            pop.setNegativeButton("No", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    dialogInterface.cancel();
                }
            });

            AlertDialog poped = pop.create();
            poped.show();
        }
    }

    public void LogClick(View view) {
        if (Username.getText().toString().isEmpty())
            Toast.makeText(this, " Please provide username", Toast.LENGTH_SHORT).show();
        else if (Password.getText().toString().isEmpty())
            Toast.makeText(this, " Please provide password", Toast.LENGTH_SHORT).show();
        else {

            for (int i = 0; i<username.size(); i++) {
                if (Username.getText().toString().equals(username.get(i).toString())) {

                    if (Password.getText().toString().equals(password.get(i).toString())) {

                        textView.setText(username.get(i).toString() + "\n" + firstname.get(i).toString() + "\n" + lastname.get(i).toString() + "\n" + email.get(i).toString());

                        Toast.makeText(this, "Login Successful", Toast.LENGTH_SHORT).show();
                    }
                }
                Username.setText("");
                Password.setText("");
                textView.setVisibility(View.VISIBLE);
            }

        }
    }




}
